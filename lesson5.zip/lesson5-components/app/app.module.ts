import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RouterModule } from "@angular/router";

import { LifecycleSampleModule } from "./01_lifecycle/lifecycle-samples.module";
import { ChildAndContentSampleModule } from "./02_child_and_content/child-and-content-samples.module";

import { AppComponent } from "./app.component";
import { routes } from "./app.routes";

@NgModule({
    imports: [
        BrowserModule,
        LifecycleSampleModule,
        ChildAndContentSampleModule,
        RouterModule.forRoot(routes)
    ],
    declarations: [AppComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }
