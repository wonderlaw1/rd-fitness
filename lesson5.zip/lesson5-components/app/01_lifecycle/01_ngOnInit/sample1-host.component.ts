import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "sample1-host",
    templateUrl: "sample1-host.component.html"
})
export class Sample1HostComponent{ }