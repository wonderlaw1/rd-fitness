"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./01_ngOnInit/sample1.component"));
__export(require("./01_ngOnInit/sample1-host.component"));
__export(require("./02_ngOnChanges/sample2.component"));
__export(require("./02_ngOnChanges/sample2-host.component"));
__export(require("./03_ngOnChanges/sample3.component"));
__export(require("./03_ngOnChanges/sample3-host.component"));
__export(require("./04_AllEvents/sample4.component"));
__export(require("./04_AllEvents/sample4-host.component"));
//# sourceMappingURL=index.js.map