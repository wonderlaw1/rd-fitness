import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "sample4-host",
    templateUrl: "sample4-host.component.html"
})
export class Sample4HostComponent { }