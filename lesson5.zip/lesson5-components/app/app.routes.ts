import { Routes } from "@angular/router";

import { Sample1HostComponent, Sample2HostComponent, Sample3HostComponent, Sample4HostComponent  } from "./01_lifecycle/index";
import { BlockHostComponent, Block2HostComponent, ListHostComponent } from "./02_child_and_content/index";

export const routes: Routes = [
    { path: "", redirectTo: "sample6", pathMatch: "full" },
    { path: "sample6", component: Sample1HostComponent },
    { path: "sample7", component: Sample2HostComponent },
    { path: "sample8", component: Sample3HostComponent },
    { path: "sample9", component: Sample4HostComponent },
    { path: "sample10", component: BlockHostComponent },
    { path: "sample11", component: Block2HostComponent },
    { path: "sample12", component: ListHostComponent },
];
