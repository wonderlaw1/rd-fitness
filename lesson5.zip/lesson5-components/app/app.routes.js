"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var index_1 = require("./01_lifecycle/index");
var index_2 = require("./02_child_and_content/index");
exports.routes = [
    { path: "", redirectTo: "sample6", pathMatch: "full" },
    { path: "sample6", component: index_1.Sample1HostComponent },
    { path: "sample7", component: index_1.Sample2HostComponent },
    { path: "sample8", component: index_1.Sample3HostComponent },
    { path: "sample9", component: index_1.Sample4HostComponent },
    { path: "sample10", component: index_2.BlockHostComponent },
    { path: "sample11", component: index_2.Block2HostComponent },
    { path: "sample12", component: index_2.ListHostComponent },
];
//# sourceMappingURL=app.routes.js.map