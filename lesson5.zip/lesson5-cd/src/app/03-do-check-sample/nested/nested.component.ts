import { Component, DoCheck, OnChanges, Input, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import {interval} from 'rxjs/observable/interval';
import {tap} from 'rxjs/operators';

@Component({
  selector: 'app-nested',
  templateUrl: './nested.component.html',
  styleUrls: ['./nested.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NestedComponent implements DoCheck, OnChanges {

  myValue: number;

  @Input() settings;
  id: number;

  // ChangeDetectorRef - ChangeDetector, который привязан к отдельному компоненту и выполняет операции отслеживания изменений.
  constructor(private cd: ChangeDetectorRef) { }

  ngOnInit() {
    interval(1000).pipe(
      tap(value => {
        console.log(value);
        this.myValue = value as number;
        this.cd.markForCheck();
      })
    ).subscribe();
  }

  ngOnChanges() {
    this.id = this.settings.id;
  }

  // Стратегия текущего компонента OnPush
  // Значения свойств объекта в settings будут изменяться но ссылка останется прежней
  // Метод ngDoCheck будет срабатывать постоянно, даже если не менялось input свойство
  // Это позволит самостоятельно отследить изменения и обновить текущий компонент если это потребуется
  ngDoCheck() {
    if(this.id != this.settings.id) {
      this.id = this.settings.id;
      this.cd.markForCheck(); // обновить view
    }
  }
}


