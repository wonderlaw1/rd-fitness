import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {CdSampleComponent} from './01-change-detection/cd-sample/cd-sample.component';
import {CdStrategiesSampleComponent} from './02-cd-strategies/cd-strategies-sample/cd-strategies-sample.component';
import {MainComponent} from './03-do-check-sample/main/main.component';


const routes: Routes = [
  {path: '', pathMatch: 'full', redirectTo: 'sample1'},
  {path: 'sample1', component: CdSampleComponent},
  {path: 'sample2', component: CdStrategiesSampleComponent},
  {path: 'sample3', component: MainComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
